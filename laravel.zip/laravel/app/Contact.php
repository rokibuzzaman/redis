<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Contact extends Model 
{
	public $timestamps = false;
	
	protected $table = 'contacts';
	

	protected $fillable = [
		'first_name',
        'last_name',
        'email',
        'city',
        'country',
        'job_title'  
	];


}